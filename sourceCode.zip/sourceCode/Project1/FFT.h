#include<complex>

class Complex
{
public:
	float real;
	float imag;

	Complex() {
		real = 0;
		imag = 0;
	}
};

void FFT(Complex* TD, Complex* FD, int r);