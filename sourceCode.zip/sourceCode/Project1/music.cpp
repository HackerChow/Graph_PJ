#include "music.h"

AudioPlayer::AudioPlayer(std::string file) 
{
	this->filepath = file;
	this->loadCommand = "OPEN " + this->filepath + " ALIAS MUSIC";
	this->closeCommand = "CLOSE MUSIC";
	this->playCommand = "PLAY MUSIC FROM 0";
	this->statusCommand = "status MUSIC mode";
}

void AudioPlayer::open(std::string file)
{
	this->filepath = file;
}

bool AudioPlayer::sendToMCI(std::string command)
{
	if (!mciSendString(command.c_str(), NULL, 0, 0))
		return true;
	return false;
}

void AudioPlayer::load()
{
	if (this->sendToMCI(this->loadCommand))
		std::cout << "load music success\n" << std::endl;
	else
		std::cout << "can not load music \n" << std::endl;
}

void AudioPlayer::close()
{
	if(this->sendToMCI(this->closeCommand))
		std::cout << "close \n" << std::endl;
	else
		std::cout << "can not close music \n" << std::endl;
}

void AudioPlayer::play()
{
	if (this->sendToMCI(this->playCommand))
		std::cout << "begin play music \n" << std::endl;
	else
		std::cout << "can not play music \n" << std::endl;
}

std::string AudioPlayer::getStatus()
{
	char message[20];
	mciSendString(this->statusCommand.c_str(), message, 20, 0);
	std::string str(message);
	return str;
}