#include <stdio.h>
#include <time.h>
#include "input.h"
#include "music.h"
#include "draw.h"
#include "wav.h"
#include "test.h"

using namespace std;

#define WIND "src\\wind.wav"
#define WINDSONG "src\\windsong.wav"

#define RATE 16000		//����Ƶ�� 16kHz
#define STEP 1600		//ÿ��ǰ����ô���
#define TIME 100		//ÿ�λ��Ƶ�ʱ�䣨ms��

vector<float> vertices;
int istart;
int iend;
int len;

//�ص����������ڵ�����Сʱ����
void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
	glViewport(0, 0, width, height);
}

void pressInput(GLFWwindow* window) {
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
}

void draw()
{
	//Complex* inarr = new Complex[len];
	//Complex* outarr = new Complex[len];

	//for (int i = 0; i < len;) {
	//	inarr[i++].real = vertices[i];
	//}

	//FFT(inarr, outarr, len);

	istart = 0;
	iend = 1600;
	int now;
	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit()){
		cout << "fail to init glf" << endl;
		return;
	}

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(800, 800, "Visualize Music ", NULL, NULL);

	if (!window)
	{
		glfwTerminate();
		return;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	/* Loop until the user closes the window */
	while (true)
	{
		now = clock();
		pressInput(window);

		/*your draw*/
		if (iend < len)
		{
			drawSequence(vertices, istart, iend);
			//drawSpectrum(outarr, istart, iend);
		}
		else {
			break;
		}

		/* Swap front and back buffers */
		glfwSwapBuffers(window);

		/* Poll for and process events */
		glfwPollEvents();
		istart += STEP;
		iend += STEP;

		if (glfwWindowShouldClose(window)) {
			break;
		}

		Sleep(TIME - (clock() - now)); //�����ӳ�
	}

	glfwTerminate();
}

int main(int argc, char* argv[])
{
	AudioPlayer audio(WINDSONG);
	audio.load();
	//test(WINDSONG);
	len = parseWav(WINDSONG, vertices);
	audio.play();
	draw();
	audio.close();
	return 0;
}
