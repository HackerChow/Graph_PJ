#include "wav.h"

using namespace std;

int parseWav(const char* filename, std::vector<float>& data)
{
	fstream fs;
	wav_struct WAV;

	fs.open(filename, ios::binary | ios::in);

	fs.seekg(0, ios::end);        //��c++���÷�������ļ���С
	WAV.file_size = fs.tellg();

	fs.seekg(0x16);
	fs.read((char*)&WAV.channel, sizeof(WAV.channel));

	fs.seekg(0x18);
	fs.read((char*)&WAV.frequency, sizeof(WAV.frequency));

	fs.seekg(0x1c);
	fs.read((char*)&WAV.Bps, sizeof(WAV.Bps));

	fs.seekg(0x22);
	fs.read((char*)&WAV.sample_num_bit, sizeof(WAV.sample_num_bit));

	fs.seekg(0x28);
	fs.read((char*)&WAV.data_size, sizeof(WAV.data_size));

	WAV.data = new unsigned char[WAV.data_size];
	fs.seekg(0x2c);
	fs.read((char*)WAV.data, sizeof(char) * WAV.data_size);

	cout << "�ļ���СΪ  ��" << WAV.file_size << endl;   
	cout << "��Ƶͨ����  ��" << WAV.channel << endl;   
	cout << "����Ƶ��    ��" << WAV.frequency << endl;   
	cout << "Byte��      ��" << WAV.Bps << endl;    
	cout << "����λ��    ��" << WAV.sample_num_bit << endl;   
	cout << "��Ƶ���ݴ�С��" << WAV.data_size << endl;  
	cout << "���10�����ݣ�" << endl;


	float max = 0.0;
	int len;
	for (unsigned long i = 0; i < WAV.data_size; i = i + 2)
	{
		//�ұ�Ϊ���
		unsigned long data_low = WAV.data[i];
		unsigned long data_high = WAV.data[i + 1];
		float data_true = data_high * 256 + data_low;
		long data_complement = 0;

		//ȡ��˵����λ������λ��
		int my_sign = (int)(data_high / 128);
		
		if (my_sign == 1) 
		{ 
			data_complement = data_true - 65536; 
		}
		else 
		{ 
			data_complement = data_true; 
		}
		
		float float_data = (float)(data_complement / (float)32768);
		if (float_data < 0) {
			float_data = -float_data;
		}
		data.push_back(float_data);
		max = (max > float_data) ? max : float_data;
	}
	fs.close();

	//��һ��
	len = data.size();
	for (int i = 0; i < len; i++)
	{
		data[i] = data[i] / (max);
	}

	return len;
}