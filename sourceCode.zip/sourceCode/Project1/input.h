#pragma once
#include <iostream>
#include <vector>

int fileOutput(std::vector<float>& vertices, const char* filepath);