#include <Windows.h>
#include <string>
#include <iostream>
#pragma comment(lib,"winmm.lib")

class AudioPlayer 
{
private:
	std::string filepath;

	std::string loadCommand;

	std::string closeCommand;

	std::string playCommand;

	std::string statusCommand;
public:
	AudioPlayer();

	AudioPlayer(std::string file);

	void open(std::string file);

	bool sendToMCI(std::string command);

	void load();

	void close();

	void play();

	std::string getStatus();
};