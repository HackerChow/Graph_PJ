#include "draw.h"

void drawSpectrum(Complex* arr, int istart, int iend)
{
	glClearColor(0, 0, 0, 0.8);
	glClear(GL_COLOR_BUFFER_BIT);
	glLineWidth(12);//�����߶ο���
	glBegin(GL_LINES);
	glColor3f(0.6, 0.6, 0.6);

	float red = 0.0f, yellow = 1.0f;
	float temp = 0.0;
	float xstart = -1.0;
	float xend = -1.0;

	
	//���Ʋ���ͼ
	for (int it = istart; it < iend; it += 1)
	{
		glColor3f(red, 1.0f, yellow);
		if (it <= (istart + iend) / 2) {
			red += 0.01;
			yellow -= 0.01;
		}
		else {
			red -= 0.01;
			yellow += 0.01;
		}
		xstart = xstart + 0.05;
		glVertex2f(xstart, 0);
		glVertex2f(xstart, arr[it].real);
	}

	glEnd();
}

void drawSequence(std::vector<float>& arr, int istart, int iend)
{
	glClearColor(0, 0, 0, 0.8);
	glClear(GL_COLOR_BUFFER_BIT);
	glLineWidth(6);//�����߶ο���
	glBegin(GL_LINES);
	glColor3f(0.6, 0.6, 0.6);

	float xstart = -1.0, temp = 0.0, xend = -1.0;
	float red = 0.0f, yellow = 1.0f;

	//���Ʋ���ͼ
	for (int it = istart; it < iend; it += 2)
	{
		glColor3f(red, 1.0f, yellow);
		if (it <= (istart + iend) / 2) {
			red += 0.01;
			yellow -= 0.01;
		}
		else {
			red -= 0.01;
			yellow += 0.01;
		}
		xstart = xstart + 0.02;
		glVertex2f(xstart, 0);
		glVertex2f(xstart, arr[it]);
	}
	glEnd();
}