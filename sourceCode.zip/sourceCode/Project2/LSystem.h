﻿#pragma once
#include <GL/glut.h>
#include "grammar.h"
#include "tree.h"
#include "transformation.h"

class State      // 当前探索状态
{
public:
	Node pos;
	Node dir;    // 当前乌龟方向,一个单位向量
	State() {}
};
class TrunkPosition     // 枝干
{
public:
	Node pos1;
	Node pos2;
	double radius;
	TrunkPosition() {}
};
class LeafPosition     // 树叶
{
public:
	Node pos1;
	Node pos2;
	double radius;//半径
	LeafPosition() {}
};

class LSystem
{
public:
	int stackpointer;
	double dx, dy, dz;    // 围绕三个坐标轴的偏转角度
	double length;     // 初始步长
	double lengthFactor; // 步长比率
	double radius;   // 初始半径
	double radiusFactor;  // 半径比率
	State curState;  // 当前的位置和旋转信息
	double leafRadius;  // 叶片半径
	Grammar grammar;    // 一个文法分析器

	vector<TrunkPosition> trunks; //  所有分支
	vector<LeafPosition> leaves;//所有叶子结点
	LSystem(Tree tree);
	void clearAll();
	void initGrammar();
	void generateFractal();
};