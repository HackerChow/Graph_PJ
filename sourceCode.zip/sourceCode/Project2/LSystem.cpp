﻿#include "LSystem.h"
GLfloat PI = 3.14;
Transformation trans;
LSystem::LSystem(Tree tree)
{
	stackpointer = 0;
	dx = tree.trunk.leap_x;
	dy = tree.trunk.leap_y;
	dz = tree.trunk.leap_z;
	length = tree.trunk.length;
	lengthFactor = tree.trunk.length_shrink;
	radius = tree.trunk.radius;
	radiusFactor = tree.trunk.radius_shrink;
	leafRadius = tree.leaf.radius;
	curState = {};
}

void LSystem::clearAll()
{
	grammar.clear();
	trunks.clear();
	leaves.clear();
}

void LSystem::initGrammar()   // 加载一个文法
{
	grammar.Iteration();
}

void LSystem::generateFractal()   // 利用加载过的文法，创建分形树
{
	trunks.clear();
	leaves.clear();
	curState.pos = Node(0, 0, 0);
	curState.dir = Node(0, 1, 0);

	State stack[3000]; // 状态栈
	for (int i = 0; i < 3000; i++)
	{
		stack[i].pos.x = 0.0;
		stack[i].pos.y = 0.0;
		stack[i].pos.z = 0.0;
		stack[i].dir.x = 0.0;
		stack[i].dir.y = 0.0;
		stack[i].dir.z = 0.0;
	}
	size_t i = 0;
	while (i < grammar.getRule().length()) {
		TrunkPosition tmp_trunk;//单个分支
		LeafPosition tmp_leaf;
		switch (grammar.getRule()[i])
		{
		case 'F':
			tmp_trunk.pos1 = curState.pos;
			curState.pos.x += length * curState.dir.x;
			curState.pos.y += length * curState.dir.y;
			curState.pos.z += length * curState.dir.z;
			tmp_trunk.pos2 = curState.pos;
			/*glColor3f(1.0, 0.0, 0.0);
			glLineWidth(3);
			glBegin(GL_LINES);
			glVertex3f(tmp_trunk.pos1.x, tmp_trunk.pos1.y, tmp_trunk.pos1.z);
			glVertex3f(tmp_trunk.pos2.x, tmp_trunk.pos2.y, tmp_trunk.pos2.z);
			glEnd();*/
			tmp_trunk.radius = radius;
			trunks.push_back(tmp_trunk);
			break;
		case 'X': //叶子
			tmp_leaf.pos1 = curState.pos;
			tmp_trunk.pos1 = curState.pos;
			curState.pos.x += length * curState.dir.x;
			curState.pos.y += length * curState.dir.y;
			curState.pos.z += length * curState.dir.z;
			tmp_trunk.pos2 = curState.pos;
			tmp_leaf.pos2 = curState.pos;
			tmp_leaf.radius = leafRadius;
			tmp_trunk.radius = radius;
			trunks.push_back(tmp_trunk);
			leaves.push_back(tmp_leaf);
			break;
		case 'A':
			length = length * lengthFactor;
			radius = radius * radiusFactor;
			break;
		case 'B':
			length = length / lengthFactor;
			radius = radius / radiusFactor;
			break;
		case '[':
			stack[stackpointer] = curState;
			stackpointer++;;
			break;
		case ']':
			curState = stack[stackpointer - 1];
			stackpointer--;
			break;
		case '+': //绕X轴		 
			trans.set(curState.dir);
			curState.dir = trans.Rotate('X', dx);
			break;
		case '-':
			trans.set(curState.dir);
			curState.dir = trans.Rotate('X', -dx);
			break;
		case '*': //绕y轴
			trans.set(curState.dir);
			curState.dir = trans.Rotate('Y', dy);
			break;
		case '/':
			trans.set(curState.dir);
			curState.dir = trans.Rotate('Y', -dy);
			break;
		case '&'://绕z轴
			trans.set(curState.dir);
			curState.dir = trans.Rotate('Z', dz);
			break;
		case '%':
			trans.set(curState.dir);
			curState.dir = trans.Rotate('Z', -dz);
			break;
		default:
			;
		}
		i++;
	}
}
