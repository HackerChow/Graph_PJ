﻿
class Node // homogeneous coordinate point
{
public:
	Node() :x(0), y(0), z(0), w(1) {}
	Node(float xx, float yy, float zz) :x(xx), y(yy), z(zz), w(1) {}
public:
	float x, y, z, w;
};
class Transformation {
public:
	Transformation() {}
	void set(Node point);
	void Identity();//单位矩阵
	Node Translate(float, float, float);//平移变换矩阵
	Node Scale(float, float, float);//比例变换矩阵
	Node Rotate(char, double);//旋转变换 (绕X或Y或Z轴旋转)
	void MultiMatrix();//矩阵相乘
public:
	Node POld;
	float T[4][4];
};