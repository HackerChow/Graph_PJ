﻿#include <GL/glut.h>
#include "LSystem.h"

//L系统

GLint WindW = 800;
GLint WindH = 600;
GLfloat oldx, oldy;//鼠标移动因子
GLfloat scale = 1.0;//放大缩小
GLfloat xangle = 15.0f;
GLfloat yangle = -15.0f;//旋转因子  
GLuint texout; //纹理
GLuint texin;
#define BMP_Header_Length 54  //图像数据在内存块中的偏移量 

GLfloat Pi1 = 3.14159;
Tree tree;
LSystem lsrule(tree);

int LoadGLTextures(char* Filename, GLuint* ttexture, int i)//ttexture[i]为用来绑定纹理数据的整数,可更改  
{
	FILE* File;
	BITMAPINFOHEADER header;
	BYTE* texture;//texture长宽和像素RGBA texture[width][height][4]  
	int width, height, m, j;
	unsigned char* image;
	fopen_s(&File, Filename, "rb");
	if (File == NULL) {
		cout << "读取图片失败" << endl;
	}
	//读取BMP信息头，跳过14字节文件头  
	if (File) {
		fseek(File, 14, SEEK_SET);
		fread(&header, sizeof(BITMAPINFOHEADER), 1, File);
	}
	else return FALSE;
	//读取长宽  
	width = header.biWidth;
	height = header.biHeight;
	//为image分配像素空间，读取图片数据，为texture分配width*height*4的四位空间用来生成纹理  
	image = (unsigned char*)malloc(width * height * 3);
	fread(image, sizeof(unsigned char), width * height * 3, File);//唯一的不足之处在于将3字节像素读为一维字符串  
	texture = (BYTE*)malloc(width * height * 4);// 唯一的不足之处在于将4字节像素读为一维字符串  
											   //以下代码将对texture重排列，一般来说为Blue Green Red Alpha格式(24位图格式),生成纹理使用BGRA模式  
											   /****************************************修改模块,通过像素任意修改图片，示例:*************************************************************/
											   //本段代码将纯黑色像素点透明度(Alpha)设为100%,其余颜色设为0%  
	for (m = 0; m < width; m++)
	{
		for (j = 0; j < height; j++)
		{
			//把颜色值写入   
			texture[m * width * 4 + j * 4] = image[m * width * 3 + j * 3];
			texture[m * width * 4 + j * 4 + 1] = image[m * width * 3 + j * 3 + 1];
			texture[m * width * 4 + j * 4 + 2] = image[m * width * 3 + j * 3 + 2];
			//设置alpha值,假设黑色为透明色   

			if (texture[m * width * 4 + j * 4] >= 200 && texture[m * width * 4 + j * 4 + 1] >= 200 && texture[m * width * 4 + j * 4 + 2] >= 200) {
				texture[m * width * 4 + j * 4 + 3] = 0;                 //透明，alpha=0   
			}
			else
				texture[m * width * 4 + j * 4 + 3] = 255;           //不透明，alpha=255  
		}
	}
	//ttexture[i]为绑定纹理的整数  
	//下面生成纹理以及纹理处理  
	glGenTextures(1, &ttexture[i]);
	glBindTexture(GL_TEXTURE_2D, ttexture[i]);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D, 0, 4, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, texture);
	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, width, height, GL_BGRA_EXT, GL_UNSIGNED_BYTE, texture);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glAlphaFunc(GL_GREATER, 0.5);//使Alpha值生效  
								 //纹理生成完毕,下面释放空间  
	free(texture);
	free(image);                        // 释放图像数据  
	return TRUE;                                // 返回 Status  
}
int power_of_two(int n)
{
	if (n <= 0)
		return 0;
	return (n & (n - 1)) == 0;
}
//读取纹理
GLuint load_texture(const char* file_name)
{
	GLint width, height, total_bytes;
	GLubyte* pixels = 0;
	GLuint last_texture_ID = 0, texture_ID = 0;

	// 打开文件，如果失败，返回  
	FILE* pFile;
	fopen_s(&pFile, file_name, "rb");
	if (pFile == 0)
		return 0;

	// 读取文件中图象的宽度和高度  
	fseek(pFile, 0x0012, SEEK_SET);
	fread(&width, 4, 1, pFile);
	fread(&height, 4, 1, pFile);
	fseek(pFile, BMP_Header_Length, SEEK_SET);

	// 计算每行像素所占字节数，并根据此数据计算总像素字节数  
	{
		GLint line_bytes = width * 3;
		while (line_bytes % 4 != 0)
			++line_bytes;
		total_bytes = line_bytes * height;
	}

	// 根据总像素字节数分配内存  
	pixels = (GLubyte*)malloc(total_bytes);
	if (pixels == 0)
	{
		fclose(pFile);
		return 0;
	}

	// 读取像素数据  
	if (fread(pixels, total_bytes, 1, pFile) <= 0)
	{
		free(pixels);
		fclose(pFile);
		return 0;
	}

	// 对就旧版本的兼容，如果图象的宽度和高度不是的整数次方，则需要进行缩放  
	// 若图像宽高超过了OpenGL规定的最大值，也缩放  
	{
		GLint max;
		glGetIntegerv(GL_MAX_TEXTURE_SIZE, &max);
		if (!power_of_two(width)
			|| !power_of_two(height)
			|| width > max
			|| height > max)
		{
			const GLint new_width = 256;
			const GLint new_height = 256; // 规定缩放后新的大小为边长的正方形  
			GLint new_line_bytes, new_total_bytes;
			GLubyte* new_pixels = 0;

			// 计算每行需要的字节数和总字节数  
			new_line_bytes = new_width * 3;
			while (new_line_bytes % 4 != 0)
				++new_line_bytes;
			new_total_bytes = new_line_bytes * new_height;

			// 分配内存  
			new_pixels = (GLubyte*)malloc(new_total_bytes);
			if (new_pixels == 0)
			{
				free(pixels);
				fclose(pFile);
				return 0;
			}

			// 进行像素缩放  
			gluScaleImage(GL_RGB,
				width, height, GL_UNSIGNED_BYTE, pixels,
				new_width, new_height, GL_UNSIGNED_BYTE, new_pixels);

			// 释放原来的像素数据，把pixels指向新的像素数据，并重新设置width和height  
			free(pixels);
			pixels = new_pixels;
			width = new_width;
			height = new_height;
		}
	}

	// 分配一个新的纹理编号  
	glGenTextures(1, &texture_ID);
	if (texture_ID == 0)
	{
		free(pixels);
		fclose(pFile);
		return 0;
	}

	// 绑定新的纹理，载入纹理并设置纹理参数  
	// 在绑定前，先获得原来绑定的纹理编号，以便在最后进行恢复  
	GLint lastTextureID = last_texture_ID;
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &lastTextureID);
	glBindTexture(GL_TEXTURE_2D, texture_ID);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0,
		GL_BGR_EXT, GL_UNSIGNED_BYTE, pixels);
	glBindTexture(GL_TEXTURE_2D, lastTextureID);  //恢复之前的纹理绑定  
	free(pixels);
	return texture_ID;
}

void  init()
{
	//glClearColor(0.0, 0.0, 1.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-25.0, 25.0, -25.0, 25.0, -25.0, 25.0);
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);    // 启用纹理 
	//使alpha值生效
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	//
	lsrule.initGrammar();//将文法迭代好
	lsrule.generateFractal();//把树的树枝等先算好
	//cout << lsrule.grammar.getRule() << endl;//成功迭代好
}

//以yuandian两端点，r为半径
void drawcone(double r, double h) {
	glBindTexture(GL_TEXTURE_2D, texin);
	for (int i = 0; i < 360; i += 50) { //在原点画了一个圆柱
		float temp = i * Pi1 / 180;
		float temp1 = (i + 50) * Pi1 / 180;
		glBegin(GL_QUADS);
		glTexCoord2f((temp * r * tree.trunk.radius_shrink) / (2 * Pi1), 0.0f); glVertex3f(r * cos(temp) * tree.trunk.radius_shrink, 0, r * sin(temp) * tree.trunk.radius_shrink);
		glTexCoord2f((temp * r) / (2 * Pi1), 1.0f); glVertex3f(r * cos(temp), h, r * sin(temp)); //竖着2倍 横着1/2
		glTexCoord2f((temp1 * r) / (2 * Pi1), 1.0f); glVertex3f(r * cos(temp1), h, r * sin(temp1));
		glTexCoord2f((temp1 * r * tree.trunk.radius_shrink) / (2 * Pi1), 0.0f); glVertex3f(r * cos(temp1) * tree.trunk.radius_shrink, 0.0f, r * sin(temp1) * tree.trunk.radius_shrink);
		glEnd();
	}
}
void  DrawChannel(Node A, Node B, double r)
{
	// 起始线段：以(0,1,0)为起点,它的长度(distance)通过目标线段计算,  
	//           终点坐标为(0,1-distance,0)  
	// 目标线段：以(x1,y1,z1)为起点，以(x2,y2,z2)为终点  
	// 计算目标向量  
	GLfloat   dx = B.x - A.x;
	GLfloat   dy = B.y - A.y;
	GLfloat   dz = B.z - A.z;
	// 算出目标向量模(即AB长度)  
	GLfloat   distance = sqrt(dx * dx + dy * dy + dz * dz);
	// 计算平移量  
	GLfloat  px = A.x;
	GLfloat  py = A.y - 1;
	GLfloat  pz = A.z;
	// 起始线段的末端点  
	GLfloat  bx = px;
	GLfloat  by = (1 - distance) + py;
	GLfloat  bz = pz;
	// 计算起始向量  
	GLfloat  sx = bx - A.x;
	GLfloat  sy = by - A.y;
	GLfloat  sz = bz - A.z;
	// 计算向量(sx,sy,sz)与向量(dx,dy,dz)的法向量(sy*dz - dy*sz,sz*dx - sx*dz,sx*dy - dx*sy)  
	GLfloat fx = sy * dz - dy * sz;
	GLfloat fy = sz * dx - sx * dz;
	GLfloat fz = sx * dy - dx * sy;
	// 求两向量间的夹角  
	// 计算第三条边的长度  
	GLfloat ax = fabs(B.x - bx);
	GLfloat ay = fabs(B.y - by);
	GLfloat az = fabs(B.z - bz);
	GLfloat length = sqrt(ax * ax + ay * ay + az * az);
	// 根据余弦定理计算夹角  
	GLfloat angle = acos((distance * distance * 2 - length * length) / (2 * distance * distance)) * 180.0f / 3.14159;
	// 绘制圆柱   
	glPushMatrix();
	// 变换的顺序与函数书写的顺序相反，  
	// 即先平移(0,-1,0)，再绕法向量旋转，最后再平移  
	glTranslatef(A.x, A.y, A.z);
	glRotatef(angle, fx, fy, fz);
	glTranslatef(0, -distance, 0);
	drawcone(r, distance);
	glPopMatrix();
}
void drawsquare(double r) {
	glRotated(180, 0, 0, 1);
	glBindTexture(GL_TEXTURE_2D, texout);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(r / 2, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 1.0f); glVertex3f(r / 2, r, 0);
	glTexCoord2f(1.0f, 1.0f); glVertex3f(-r / 2, r, 0);
	glTexCoord2f(1.0f, 0.0f); glVertex3f(-r / 2, 0, 0);

	glEnd();
}
void DrawLeaf(Node A, Node B, double r) {
	// 起始线段：以(0,1,0)为起点,它的长度(distance)通过目标线段计算,  
	//           终点坐标为(0,1-distance,0)  
	// 目标线段：以(x1,y1,z1)为起点，以(x2,y2,z2)为终点  
	// 计算目标向量  
	GLfloat   dx = B.x - A.x;
	GLfloat   dy = B.y - A.y;
	GLfloat   dz = B.z - A.z;
	// 算出目标向量模(即AB长度)  
	GLfloat   distance = sqrt(dx * dx + dy * dy + dz * dz);
	// 计算平移量  
	GLfloat  px = A.x;
	GLfloat  py = A.y - 1;
	GLfloat  pz = A.z;
	// 起始线段的末端点  
	GLfloat  bx = px;
	GLfloat  by = (1 - distance) + py;
	GLfloat  bz = pz;
	// 计算起始向量  
	GLfloat  sx = bx - A.x;
	GLfloat  sy = by - A.y;
	GLfloat  sz = bz - A.z;
	// 计算向量(sx,sy,sz)与向量(dx,dy,dz)的法向量(sy*dz - dy*sz,sz*dx - sx*dz,sx*dy - dx*sy)  
	GLfloat fx = sy * dz - dy * sz;
	GLfloat fy = sz * dx - sx * dz;
	GLfloat fz = sx * dy - dx * sy;
	// 求两向量间的夹角  
	// 计算第三条边的长度  
	GLfloat ax = fabs(B.x - bx);
	GLfloat ay = fabs(B.y - by);
	GLfloat az = fabs(B.z - bz);
	GLfloat length = sqrt(ax * ax + ay * ay + az * az);
	// 根据余弦定理计算夹角  
	GLfloat angle = acos((distance * distance * 2 - length * length) / (2 * distance * distance)) * 180.0f / 3.14159;
	glPushMatrix();
	// 变换的顺序与函数书写的顺序相反，  
	// 即先平移(0,-1,0)，再绕法向量旋转，最后再平移  
	glTranslatef(A.x, A.y, A.z);
	glRotatef(angle, fx, fy, fz);
	glTranslatef(0, -distance, 0);
	drawsquare(r);
	glPopMatrix();
}
void  display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glLoadIdentity();
	glColor4f(1.0, 1.0, 1.0, 1.0);
	//glPushMatrix();
	glRotatef(xangle, 1.0, 0.0, 0.0);
	glRotatef(yangle, 0.0, 1.0, 0.0);//旋转
	glScalef(scale, scale, scale);
	glTranslatef(0, -20, 0);
	for (int i = 0; i < lsrule.trunks.size(); i++) {//画树干
		/*cout << lsrule.trunks[i].radius << endl;*/
		DrawChannel(lsrule.trunks[i].pos1, lsrule.trunks[i].pos2, lsrule.trunks[i].radius);
	}
	for (int i = 0; i < lsrule.leaves.size(); i++) {//画树叶
		/*cout << lsrule.trunks[i].radius << endl;*/
		DrawLeaf(lsrule.leaves[i].pos1, lsrule.leaves[i].pos2, tree.leaf.radius);
	}
	/*glEnable(GL_TEXTURE_2D);
	DrawChannel(lsrule.trunks[1].pos1, lsrule.trunks[1].pos2);*/
	/*glDisable(GL_TEXTURE_2D);
	glColor3f(1.0, 0.0, 0.0);
	glPointSize(5);
	glBegin(GL_POINTS);
	glVertex3f(lsrule.trunks[1].pos1.x, lsrule.trunks[1].pos1.y, lsrule.trunks[1].pos1.z);
	glVertex3f(lsrule.trunks[1].pos2.x, lsrule.trunks[1].pos2.y, lsrule.trunks[1].pos2.z);
	glEnd();*/
	//glPopMatrix();
	glFlush();
	glutSwapBuffers();
}
void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	GLfloat f = 25.0f;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (w <= h)
		glOrtho(-f, f, -f * (GLfloat)h / (GLfloat)w,
			f * (GLfloat)h / (GLfloat)w, -f, f);
	else
		glOrtho(-f * (GLfloat)w / (GLfloat)h,
			f * (GLfloat)w / (GLfloat)h, -f, f, -f, f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
void keyboard(unsigned char key, int x, int y)
{
	char b[] = "res//Maple1.bmp";
	char c[] = "res//星状叶.bmp";
	switch (key)
	{
	case 'w':  //放大
	case 'W':
		scale += 0.25;
		break;
	case 's':  //缩小
	case 'S':
		if (scale <= 0)
			return;
		scale -= 0.25;
		break;
	case 'z':  //树叶放大
	case 'Z':
		tree.leaf.radius *= 0.75;
		break;
	case 'x':  //树叶缩小
	case 'X':
		tree.leaf.radius /= 0.75;
		break;
	case 'r':  //树枝半径增大
	case 'R':
		for (int i = 0; i < lsrule.trunks.size(); i++)
			lsrule.trunks[i].radius += 0.025;
		break;
	case 't':  //树枝半径减小
	case 'T':
		for (int i = 0; i < lsrule.trunks.size(); i++)
		{
			lsrule.trunks[i].radius -= 0.025;
			if (lsrule.trunks[i].radius < 0)
				lsrule.trunks[i].radius += 0.025;
		}
		break;
	case 'q':  //切换树叶
	case 'Q':
		//LoadGLTextures(a, &texin, 0);
		LoadGLTextures(b, &texout, 0);
		break;
	case 'f':  //切换树叶
	case 'F':
		//LoadGLTextures(a, &texin, 0);
		LoadGLTextures(c, &texout, 0);
		break;
	case 'e':  //切换树干
	case 'E':
		texin = load_texture("res//tree.bmp");  //加载纹理
		break;
	case 'h':  //切换树干
	case 'H':
		texin = load_texture("res//bark1.bmp");  //加载纹理
		break;
		//case 'f':  //树枝半径收缩率
		//case 'F':
		//	tree.trunk.length_shrink += 0.25;
		//	for (int i = 0; i<lsrule.trunks.size(); i++)
		//		lsrule.trunks[i].radius += 0.25;
		//	break;
		//case 'g':  //xiao
		//case 'G':
		//	tree.trunk.radius_shrink -= 0.05;
		//	break;
		//case 'c':  //迭代次数
		//case 'C':
		//	lsrule.grammar.level += 1;
		//	lsrule.initGrammar();//将文法迭代好
		//	lsrule.generateFractal();//把树的树枝等先算好
		//	break;
		//case 'v':  
		//case 'V':
		//	lsrule.grammar.level -= 1;
		//	lsrule.initGrammar();//将文法迭代好
		//	lsrule.generateFractal();//把树的树枝等先算好
		//	break;
		//case 'a':  //树枝长度
		//case 'A':
		//	lsrule.clearAll();
		//	tree.trunk.length += 0.25;
		//	lsrule.initGrammar();//将文法迭代好
		//	lsrule.generateFractal();//把树的树枝等先算好
		//	break;
		//case 'd':  //xiao
		//case 'D':
		//	tree.trunk.length -= 0.25;
		//	lsrule.clearAll();
		//	lsrule.initGrammar();//将文法迭代好
		//	lsrule.generateFractal();//把树的树枝等先算好
		//	break;

	}
	glutPostRedisplay();
}
void mouse(int btn, int state, int x, int y)
{
	if ((btn == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN)) {
		oldx = x; oldy = y;
	}
}
void motion(int x, int y)
{
	GLint deltax = oldx - x;
	GLint deltay = oldy - y;
	yangle += 360 * (GLfloat)deltax / (GLfloat)WindW;//根据屏幕上鼠标滑动的距离来设置旋转的角度  
	xangle += 360 * (GLfloat)deltay / (GLfloat)WindH;
	oldx = x;//记录此时的鼠标坐标，更新鼠标坐标,否则旋转将不可控 
	oldy = y;
	glutPostRedisplay();
}

int  main(int  argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowPosition(200, 100);
	glutInitWindowSize(800, 600);
	glutCreateWindow("Project 2");
	//char a[] = "tree.bmp";*/
	char b[] = "res/silver.bmp";
	//LoadGLTextures(a, &texin, 0);
	LoadGLTextures(b, &texout, 0);
	texin = load_texture("res/bark2.bmp");  //加载纹理
	//texout = load_texture("Maple.png");  //加载纹理
	glutReshapeFunc(reshape);
	glutDisplayFunc(display);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	glutKeyboardFunc(keyboard);
	init();
	glutMainLoop();
	return 0;
}
