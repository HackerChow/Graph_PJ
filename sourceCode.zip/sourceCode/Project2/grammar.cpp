﻿// Grammar.cpp
#include "grammar.h"

void Grammar::clear()
{
	grammar.clear();
}
void Grammar::Iteration() {
	string temprule = grammar;
	for (int i = 1; i <= level; i++)
	{
		int curlen = temprule.length();
		int j = 0;
		while (j < curlen)
		{
			if (temprule[j] == 'X')//迭代，将其中的F替换成文法模型
			{
				rule += grammar;
				j++;
			}
			else //保留转角
			{
				rule += temprule[j];
				j++;
			}
		}
		temprule = rule;
		rule.clear();
	}
	rule = temprule;//迭代好之后的文法规则
}
void Grammar::setGrammarName(const string& ref)
{
	Gname = ref;
}
void Grammar::setLevel(int num)
{
	level = num;
}
string Grammar::getGrammarName()
{
	return Gname;
}
int Grammar::getLevel()
{
	return level;
}
string Grammar::getRule()
{
	return rule;
}