﻿// Grammar.h 文法分析器类头文件

#include <iostream>
#include <string>
#include <vector>
using namespace std;
class Grammar
{
public:
	string Gname;  // 文法名
	int level = 5;        // 迭代层次
	string grammar = "FA[*+X][-/&X][/%X]B";//文法
	string rule;   // 迭代好之后的文法规则

	Grammar() {}
	void clear();   // 清除所有数据
	void Iteration();//迭代
	void setGrammarName(const string& ref);
	void setLevel(int num);
	string getGrammarName();
	int getLevel();
	string getRule();
};